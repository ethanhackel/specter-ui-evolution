# 👻 SPECTER — Anonymous Stranger Chat Platform

> **Connect. Converse. Vanish.**  
> A production-ready, anonymous real-time chat platform built with Node.js, Socket.io, and a cinematic cyberpunk UI.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Tech Stack](#tech-stack)
- [Features](#features)
- [Architecture](#architecture)
- [Project Structure](#project-structure)
- [Setup & Installation](#setup--installation)
- [Configuration](#configuration)
- [API Reference](#api-reference)
- [Socket.io Events](#socketio-events)
- [Database Schema](#database-schema)
- [Frontend Pages](#frontend-pages)
- [Admin Dashboard](#admin-dashboard)
- [Deployment Guide](#deployment-guide)
- [Future Development Roadmap](#future-development-roadmap)
- [Security Considerations](#security-considerations)

---

## Overview

SPECTER is an anonymous one-on-one stranger chat platform. Users can connect instantly with no account required, or optionally register to unlock a persona system, interest-based matching, and karma rankings.

### Core Mechanism

1. User visits `/chat` → enters the matching queue via Socket.io
2. Server pairs two queued sockets into a private room (UUID)
3. Both users chat in real-time via Socket.io room messaging
4. Either user can leave at any time — both are notified
5. Post-chat rating system collects karma data
6. All sessions tracked in SQLite for admin analytics

---

## Tech Stack

| Layer      | Technology          | Purpose                        |
|------------|---------------------|-------------------------------|
| Runtime    | Node.js v18+        | Server runtime                 |
| Framework  | Express 4.x         | HTTP server + API routes       |
| Real-time  | Socket.io 4.x       | WebSocket bidirectional chat   |
| Database   | SQLite (better-sqlite3) | Persistent storage         |
| Auth       | JWT + bcryptjs      | Session tokens + passwords     |
| Frontend   | Vanilla HTML/CSS/JS | No framework, fast load times  |
| Fonts      | Google Fonts        | Orbitron, Syne, Space Mono     |
| Hosting    | Any Node.js host    | Railway, Render, VPS, etc.     |

---

## Features

### Anonymous Chat
- Zero-friction entry — no login required
- Ghost identity auto-assigned per session
- No IP logging, no message persistence (by default)

### Matching Engine
- Real-time FIFO queue via Socket.io
- Interest-based matching tags (optional)
- Skip partner → instantly re-queue

### Messaging
- Real-time text messages
- Live typing indicators
- Emoji quick-insert bar
- Auto-resizing textarea
- Message timestamps

### User Accounts (Optional)
- Register with username + optional email
- JWT cookie authentication (7-day sessions)
- Persistent handle across sessions
- Avatar color assignment

### Karma System
- Rate conversations 1–5 stars after each chat
- Karma scores tracked per user

### Safety Tools
- One-click partner reporting
- 5 report categories
- Admin review workflow
- IP ban capability (extensible)

### Admin Dashboard
- Live online user count
- Total chats, messages, users stats
- User management (ban/unban)
- Session log viewer
- Report queue management
- Auto-refresh every 15 seconds

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                        CLIENT                           │
│  Browser ──→ Socket.io Client ──→ HTTP Fetch (REST API) │
└──────────────────────┬──────────────────────────────────┘
                       │ WebSocket + HTTP
┌──────────────────────▼──────────────────────────────────┐
│                    NODE.JS SERVER                        │
│                                                         │
│  Express App                                            │
│  ├── Static file serving (/frontend)                    │
│  ├── REST API (/api/auth/*, /api/stats, /api/admin/*)   │
│  └── Socket.io Server                                   │
│      ├── Waiting Queue (Array)                          │
│      ├── Active Rooms (Object: roomId → sockets)        │
│      └── Socket→Room Map (Object)                       │
│                                                         │
│  SQLite Database (specter.db)                           │
│  ├── users                                              │
│  ├── chat_sessions                                      │
│  ├── messages                                           │
│  ├── ratings                                            │
│  ├── reports                                            │
│  └── stats                                              │
└─────────────────────────────────────────────────────────┘
```

### Matching Flow

```
User A connects          User B connects
     │                        │
     ▼                        ▼
 find_match             find_match
     │                        │
     ▼                        │
queue=[A]                     │
                              ▼
                    queue=[A] → match A+B
                              │
              ┌───────────────▼───────────────┐
              │         Room Created           │
              │  roomId=uuid, sessionId=uuid   │
              │  A.join(room), B.join(room)    │
              └───────────────┬───────────────┘
                              │
              ┌───────────────▼───────────────┐
              │  emit('matched') to both      │
              │  Chat begins                  │
              └───────────────────────────────┘
```

---

## Project Structure

```
specter-chat/
├── backend/
│   ├── server.js          # Main Express + Socket.io server
│   ├── package.json       # Node.js dependencies
│   ├── .env.example       # Environment variable template
│   └── specter.db         # SQLite database (auto-created)
│
├── frontend/
│   ├── index.html         # Landing page (animated hero)
│   ├── chat.html          # Main chat interface
│   ├── login.html         # Sign in page
│   ├── register.html      # Registration page
│   └── admin.html         # Admin dashboard
│
└── README.md              # This file
```

---

## Setup & Installation

### Prerequisites

- Node.js v18 or higher
- npm v8 or higher

### Steps

```bash
# 1. Clone or download the project
cd specter-chat

# 2. Install backend dependencies
cd backend
npm install

# 3. Configure environment
cp .env.example .env
# Edit .env with your settings

# 4. Start the server
npm start
# Or for development with auto-reload:
npm run dev

# 5. Visit in browser
# http://localhost:3000
```

The SQLite database `specter.db` is auto-created on first run.

---

## Configuration

Edit `backend/.env`:

```env
PORT=3000
JWT_SECRET=your_super_secret_key_min_32_chars
ADMIN_USERNAME=admin
ADMIN_PASSWORD=your_secure_admin_password
NODE_ENV=production
```

**Important:** Change `JWT_SECRET` and `ADMIN_PASSWORD` before deploying to production.

---

## API Reference

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register new user |
| POST | `/api/auth/login` | Login, sets JWT cookie |
| POST | `/api/auth/logout` | Clear auth cookie |
| GET | `/api/auth/me` | Get current user info |

**Register Body:**
```json
{ "username": "string", "email": "string (optional)", "password": "string" }
```

**Login Body:**
```json
{ "username": "string", "password": "string" }
```

### Stats

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/stats` | Public stats (online, totals) |

### Admin (requires admin JWT)

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/dashboard` | Full dashboard data |
| GET | `/api/admin/users` | All users list |
| GET | `/api/admin/sessions` | Recent sessions |
| POST | `/api/admin/ban` | Ban a user |
| POST | `/api/admin/unban` | Unban a user |
| POST | `/api/admin/report/:id/resolve` | Resolve a report |

---

## Socket.io Events

### Client → Server

| Event | Payload | Description |
|-------|---------|-------------|
| `find_match` | `{ username, interests[] }` | Join matching queue |
| `cancel_search` | — | Leave queue |
| `message` | `{ content, type }` | Send a chat message |
| `typing_start` | — | Signal typing started |
| `typing_stop` | — | Signal typing stopped |
| `leave_chat` | — | Disconnect from current chat |
| `rate_partner` | `{ sessionId, score, partnerSocketId }` | Submit rating |
| `report_partner` | `{ sessionId, partnerSocketId, reason }` | Submit report |

### Server → Client

| Event | Payload | Description |
|-------|---------|-------------|
| `stats` | `{ online, total_chats, total_messages }` | Site-wide stats on connect |
| `online_count` | `number` | Live online user count |
| `waiting` | — | Entered queue, waiting |
| `search_cancelled` | — | Search was cancelled |
| `matched` | `{ roomId, partnerName, sessionId }` | Match found |
| `message` | `{ content, type, from, timestamp }` | Received message |
| `stranger_typing` | `boolean` | Partner typing state |
| `partner_left` | `{ sessionId, partnerSocketId }` | Partner disconnected |
| `report_submitted` | `{ message }` | Report confirmation |
| `error` | `{ message }` | Error notification |

---

## Database Schema

### users
```sql
id, uuid, username, email, password_hash,
avatar_color, total_chats, karma,
is_banned, ban_reason, is_admin,
created_at, last_seen
```

### chat_sessions
```sql
id, session_id, user1_id, user2_id,
user1_socket, user2_socket, message_count,
started_at, ended_at, duration_seconds, ended_by
```

### messages
```sql
id, session_id, sender_socket, sender_label,
content, msg_type, sent_at
```

### ratings
```sql
id, session_id, rater_socket, rated_socket,
score (1-5), created_at
```

### reports
```sql
id, session_id, reporter_socket, reported_socket,
reason, status (pending/resolved), created_at
```

### stats
```sql
id=1, total_chats, total_messages, total_users, updated_at
```

---

## Frontend Pages

| Route | File | Description |
|-------|------|-------------|
| `/` | `index.html` | Landing page — hero, features, how it works |
| `/chat` | `chat.html` | Main chat interface |
| `/login` | `login.html` | Sign in |
| `/register` | `register.html` | Create account |
| `/admin` | `admin.html` | Admin dashboard |

---

## Admin Dashboard

Access at `/admin`. Log in with your admin credentials from `.env`.

Features:
- **Stats overview**: online users, total chats, messages, users, pending reports
- **Users tab**: search, view all registered users, ban/unban
- **Sessions tab**: recent chat sessions with message counts and durations
- **Reports tab**: pending reports with resolve action
- Auto-refreshes every 15 seconds

---

## Deployment Guide

### Railway (Recommended)

```bash
# Install Railway CLI
npm i -g @railway/cli

# Login and deploy
railway login
railway init
railway up
```

Set environment variables in Railway dashboard.

### Render

1. Create new Web Service
2. Connect GitHub repo
3. Build command: `cd backend && npm install`
4. Start command: `cd backend && node server.js`
5. Add env vars in dashboard

### VPS (Ubuntu)

```bash
# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install nodejs

# Install PM2
npm install -g pm2

# Run app
cd specter-chat/backend
npm install
pm2 start server.js --name specter
pm2 startup
pm2 save

# Nginx reverse proxy (optional)
# proxy_pass http://localhost:3000
```

### Docker

```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY backend/package*.json ./
RUN npm ci --only=production
COPY backend/ ./backend/
COPY frontend/ ./frontend/
WORKDIR /app/backend
EXPOSE 3000
CMD ["node", "server.js"]
```

---

## Future Development Roadmap

### Phase 2 — Enhanced Matching
- [ ] Interest-weighted matching algorithm
- [ ] Country/language filter
- [ ] Gender filter (optional self-declaration)
- [ ] Age verification gate

### Phase 3 — Rich Media
- [ ] Image sharing (with moderation)
- [ ] GIF support via Giphy API
- [ ] Voice messages (Web Audio API)
- [ ] Markdown message rendering

### Phase 4 — Social Features
- [ ] Friend system (save stranger contact)
- [ ] Leaderboard by karma
- [ ] Achievements / badges
- [ ] Streak tracking

### Phase 5 — Monetization
- [ ] Premium subscription (Stripe)
- [ ] Premium perks: priority matching, gender filter, no ads
- [ ] Virtual gifts / tokens
- [ ] Verified accounts

### Phase 6 — Video Chat
- [ ] WebRTC peer-to-peer video
- [ ] TURN/STUN server integration
- [ ] Screen sharing mode

### Phase 7 — Mobile Apps
- [ ] React Native mobile app
- [ ] Push notifications (FCM)
- [ ] Background service

### Phase 8 — AI Safety
- [ ] ML-based inappropriate content detection
- [ ] Auto-moderation for hate speech
- [ ] Smart ban detection for ban evasion

### Technical Improvements
- [ ] Redis adapter for Socket.io (horizontal scaling)
- [ ] PostgreSQL migration (production scale)
- [ ] Rate limiting per IP
- [ ] CSRF protection
- [ ] Input sanitization middleware
- [ ] Automated test suite (Jest)
- [ ] CI/CD pipeline

---

## Security Considerations

### Current Implementation
- Passwords hashed with bcrypt (10 rounds)
- JWT tokens with 7-day expiry
- HttpOnly cookies prevent XSS token theft
- Input length validation on messages
- HTML escaping prevents XSS in messages

### Recommended for Production
- Add rate limiting: `npm install express-rate-limit`
- Add HTTPS (Let's Encrypt via Nginx/Caddy)
- Add helmet.js: `npm install helmet`
- Implement CSRF tokens for state-changing requests
- Add IP-based rate limiting for auth endpoints
- Regular database backups
- Set `NODE_ENV=production`

### Privacy Notes
- Anonymous users: no PII collected
- Socket IDs are ephemeral (reset on reconnect)
- Messages are stored in DB — consider adding opt-out flag
- Add privacy policy page before commercial launch

---

## License

MIT License — Free to use, modify, and deploy commercially.

---

**Built with ❤️ and 👻 — SPECTER © 2026**
