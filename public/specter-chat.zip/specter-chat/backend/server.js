require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const Database = require('better-sqlite3');

// ─── App Setup ────────────────────────────────────────────────────────────────
const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*', methods: ['GET', 'POST'] },
  pingTimeout: 60000,
  pingInterval: 25000
});

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'specter_secret_dev_key';

// ─── Database Setup ───────────────────────────────────────────────────────────
const db = new Database(path.join(__dirname, 'specter.db'));

// Initialize tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    uuid TEXT UNIQUE NOT NULL,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    password_hash TEXT NOT NULL,
    avatar_color TEXT DEFAULT '#00f5ff',
    total_chats INTEGER DEFAULT 0,
    karma INTEGER DEFAULT 0,
    is_banned INTEGER DEFAULT 0,
    ban_reason TEXT,
    is_admin INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS chat_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT UNIQUE NOT NULL,
    user1_id TEXT,
    user2_id TEXT,
    user1_socket TEXT,
    user2_socket TEXT,
    message_count INTEGER DEFAULT 0,
    started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    ended_at DATETIME,
    duration_seconds INTEGER DEFAULT 0,
    ended_by TEXT
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    sender_socket TEXT NOT NULL,
    sender_label TEXT DEFAULT 'You',
    content TEXT NOT NULL,
    msg_type TEXT DEFAULT 'text',
    sent_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS ratings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    rater_socket TEXT NOT NULL,
    rated_socket TEXT NOT NULL,
    score INTEGER NOT NULL CHECK(score >= 1 AND score <= 5),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT,
    reporter_socket TEXT,
    reported_socket TEXT,
    reason TEXT,
    status TEXT DEFAULT 'pending',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS stats (
    id INTEGER PRIMARY KEY DEFAULT 1,
    total_chats INTEGER DEFAULT 0,
    total_messages INTEGER DEFAULT 0,
    total_users INTEGER DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  INSERT OR IGNORE INTO stats (id, total_chats, total_messages, total_users)
  VALUES (1, 0, 0, 0);
`);

// Seed admin user if not exists
const adminExists = db.prepare('SELECT id FROM users WHERE is_admin = 1').get();
if (!adminExists) {
  const hash = bcrypt.hashSync(process.env.ADMIN_PASSWORD || 'specter_admin_2024', 10);
  db.prepare(`
    INSERT OR IGNORE INTO users (uuid, username, password_hash, is_admin)
    VALUES (?, ?, ?, 1)
  `).run(uuidv4(), process.env.ADMIN_USERNAME || 'specter_admin', hash);
}

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(cookieParser());
app.use(express.static(path.join(__dirname, '../frontend')));

// ─── Helpers ──────────────────────────────────────────────────────────────────
function getStats() {
  return db.prepare('SELECT * FROM stats WHERE id = 1').get();
}
function incrementStat(field, amount = 1) {
  db.prepare(`UPDATE stats SET ${field} = ${field} + ?, updated_at = CURRENT_TIMESTAMP WHERE id = 1`).run(amount);
}
function verifyToken(req) {
  const token = req.cookies?.token || req.headers?.authorization?.split(' ')[1];
  if (!token) return null;
  try { return jwt.verify(token, JWT_SECRET); } catch { return null; }
}

// ─── Auth Routes ─────────────────────────────────────────────────────────────
app.post('/api/auth/register', (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Username and password required' });
  if (username.length < 3 || username.length > 20) return res.status(400).json({ error: 'Username must be 3-20 characters' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

  const exists = db.prepare('SELECT id FROM users WHERE username = ? OR email = ?').get(username, email || '');
  if (exists) return res.status(409).json({ error: 'Username or email already taken' });

  const colors = ['#00f5ff', '#a855f7', '#f43f5e', '#10b981', '#f59e0b', '#3b82f6'];
  const color = colors[Math.floor(Math.random() * colors.length)];
  const hash = bcrypt.hashSync(password, 10);
  const uid = uuidv4();

  try {
    db.prepare(`INSERT INTO users (uuid, username, email, password_hash, avatar_color) VALUES (?, ?, ?, ?, ?)`)
      .run(uid, username, email || null, hash, color);
    incrementStat('total_users');
    const token = jwt.sign({ uuid: uid, username, is_admin: 0 }, JWT_SECRET, { expiresIn: '7d' });
    res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 3600 * 1000 });
    res.json({ success: true, username, uuid: uid, avatarColor: color });
  } catch (e) {
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ error: 'Credentials required' });

  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  if (user.is_banned) return res.status(403).json({ error: `You are banned: ${user.ban_reason || 'Violation of terms'}` });
  if (!bcrypt.compareSync(password, user.password_hash)) return res.status(401).json({ error: 'Invalid credentials' });

  db.prepare('UPDATE users SET last_seen = CURRENT_TIMESTAMP WHERE id = ?').run(user.id);
  const token = jwt.sign({ uuid: user.uuid, username: user.username, is_admin: user.is_admin }, JWT_SECRET, { expiresIn: '7d' });
  res.cookie('token', token, { httpOnly: true, maxAge: 7 * 24 * 3600 * 1000 });
  res.json({ success: true, username: user.username, uuid: user.uuid, avatarColor: user.avatar_color, isAdmin: !!user.is_admin });
});

app.post('/api/auth/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  const decoded = verifyToken(req);
  if (!decoded) return res.json({ loggedIn: false });
  const user = db.prepare('SELECT uuid, username, avatar_color, total_chats, karma, is_admin FROM users WHERE uuid = ?').get(decoded.uuid);
  if (!user) return res.json({ loggedIn: false });
  res.json({ loggedIn: true, ...user });
});

// ─── Stats Route ──────────────────────────────────────────────────────────────
app.get('/api/stats', (req, res) => {
  const stats = getStats();
  const onlineCount = waitingQueue.length + Object.keys(activeRooms).length * 2;
  res.json({ ...stats, online: Math.max(onlineCount, 0) });
});

// ─── Admin Routes ─────────────────────────────────────────────────────────────
function requireAdmin(req, res, next) {
  const decoded = verifyToken(req);
  if (!decoded?.is_admin) return res.status(403).json({ error: 'Admin access required' });
  next();
}

app.get('/api/admin/dashboard', requireAdmin, (req, res) => {
  const stats = getStats();
  const recentSessions = db.prepare(`SELECT * FROM chat_sessions ORDER BY started_at DESC LIMIT 20`).all();
  const recentUsers = db.prepare(`SELECT uuid, username, total_chats, karma, is_banned, created_at, last_seen FROM users ORDER BY created_at DESC LIMIT 20`).all();
  const pendingReports = db.prepare(`SELECT * FROM reports WHERE status = 'pending' ORDER BY created_at DESC LIMIT 10`).all();
  const onlineCount = waitingQueue.length + Object.keys(activeRooms).length * 2;
  res.json({ stats: { ...stats, online: onlineCount }, recentSessions, recentUsers, pendingReports });
});

app.post('/api/admin/ban', requireAdmin, (req, res) => {
  const { username, reason } = req.body;
  const user = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (!user) return res.status(404).json({ error: 'User not found' });
  db.prepare('UPDATE users SET is_banned = 1, ban_reason = ? WHERE username = ?').run(reason || 'Terms violation', username);
  res.json({ success: true });
});

app.post('/api/admin/unban', requireAdmin, (req, res) => {
  const { username } = req.body;
  db.prepare('UPDATE users SET is_banned = 0, ban_reason = NULL WHERE username = ?').run(username);
  res.json({ success: true });
});

app.get('/api/admin/users', requireAdmin, (req, res) => {
  const users = db.prepare(`SELECT uuid, username, email, total_chats, karma, is_banned, ban_reason, is_admin, created_at, last_seen FROM users ORDER BY created_at DESC`).all();
  res.json(users);
});

app.get('/api/admin/sessions', requireAdmin, (req, res) => {
  const sessions = db.prepare(`SELECT * FROM chat_sessions ORDER BY started_at DESC LIMIT 50`).all();
  res.json(sessions);
});

app.post('/api/admin/report/:id/resolve', requireAdmin, (req, res) => {
  db.prepare("UPDATE reports SET status = 'resolved' WHERE id = ?").run(req.params.id);
  res.json({ success: true });
});

// ─── Matching State ───────────────────────────────────────────────────────────
const waitingQueue = [];   // sockets waiting for a match
const activeRooms = {};    // roomId → { user1: socket, user2: socket, sessionId, startTime }
const socketToRoom = {};   // socketId → roomId

// ─── Socket.io Core ───────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[+] Connected: ${socket.id}`);

  // Send current stats
  const stats = getStats();
  const onlineCount = waitingQueue.length + Object.keys(activeRooms).length * 2;
  socket.emit('stats', { ...stats, online: Math.max(onlineCount, 0) });

  // Broadcast updated count
  io.emit('online_count', waitingQueue.length + Object.keys(activeRooms).length * 2);

  // ── Find Match ─────────────────────────────────────────────────────────────
  socket.on('find_match', (data) => {
    const { username, interests } = data || {};
    socket.specter = { username: username || `Ghost#${socket.id.slice(0, 4)}`, interests: interests || [] };

    // Check if already in room or queue
    if (socketToRoom[socket.id] || waitingQueue.includes(socket)) return;

    if (waitingQueue.length > 0) {
      const partner = waitingQueue.shift();
      const roomId = uuidv4();
      const sessionId = uuidv4();

      // Create session in DB
      db.prepare(`INSERT INTO chat_sessions (session_id, user1_socket, user2_socket) VALUES (?, ?, ?)`)
        .run(sessionId, partner.id, socket.id);
      incrementStat('total_chats');

      // Store room
      activeRooms[roomId] = { user1: partner, user2: socket, sessionId, startTime: Date.now(), messageCount: 0 };
      socketToRoom[partner.id] = roomId;
      socketToRoom[socket.id] = roomId;

      partner.join(roomId);
      socket.join(roomId);

      partner.emit('matched', { roomId, partnerName: socket.specter.username, sessionId });
      socket.emit('matched', { roomId, partnerName: partner.specter.username, sessionId });

      io.emit('online_count', waitingQueue.length + Object.keys(activeRooms).length * 2);
    } else {
      waitingQueue.push(socket);
      socket.emit('waiting');
      io.emit('online_count', waitingQueue.length + Object.keys(activeRooms).length * 2);
    }
  });

  // ── Cancel Search ──────────────────────────────────────────────────────────
  socket.on('cancel_search', () => {
    const idx = waitingQueue.indexOf(socket);
    if (idx !== -1) waitingQueue.splice(idx, 1);
    socket.emit('search_cancelled');
    io.emit('online_count', waitingQueue.length + Object.keys(activeRooms).length * 2);
  });

  // ── Send Message ───────────────────────────────────────────────────────────
  socket.on('message', (data) => {
    const roomId = socketToRoom[socket.id];
    if (!roomId || !activeRooms[roomId]) return;

    const { content, type } = data;
    if (!content || content.trim().length === 0) return;
    if (content.length > 2000) return socket.emit('error', { message: 'Message too long (max 2000 chars)' });

    const room = activeRooms[roomId];
    room.messageCount = (room.messageCount || 0) + 1;

    // Save to DB
    db.prepare(`INSERT INTO messages (session_id, sender_socket, content, msg_type) VALUES (?, ?, ?, ?)`)
      .run(room.sessionId, socket.id, content, type || 'text');
    incrementStat('total_messages');

    // Emit to partner
    socket.to(roomId).emit('message', {
      content,
      type: type || 'text',
      from: 'stranger',
      timestamp: new Date().toISOString()
    });
  });

  // ── Typing Indicators ──────────────────────────────────────────────────────
  socket.on('typing_start', () => {
    const roomId = socketToRoom[socket.id];
    if (roomId) socket.to(roomId).emit('stranger_typing', true);
  });

  socket.on('typing_stop', () => {
    const roomId = socketToRoom[socket.id];
    if (roomId) socket.to(roomId).emit('stranger_typing', false);
  });

  // ── Disconnect from chat ───────────────────────────────────────────────────
  socket.on('leave_chat', () => handleLeave(socket, 'user_left'));

  // ── Rate Partner ───────────────────────────────────────────────────────────
  socket.on('rate_partner', (data) => {
    const { sessionId, score, partnerSocketId } = data;
    if (!score || score < 1 || score > 5) return;

    try {
      db.prepare(`INSERT INTO ratings (session_id, rater_socket, rated_socket, score) VALUES (?, ?, ?, ?)`)
        .run(sessionId, socket.id, partnerSocketId, score);
    } catch (e) { /* duplicate rating, ignore */ }
  });

  // ── Report Partner ─────────────────────────────────────────────────────────
  socket.on('report_partner', (data) => {
    const { sessionId, partnerSocketId, reason } = data;
    db.prepare(`INSERT INTO reports (session_id, reporter_socket, reported_socket, reason) VALUES (?, ?, ?, ?)`)
      .run(sessionId, socket.id, partnerSocketId, reason || 'Inappropriate behavior');
    socket.emit('report_submitted', { message: 'Report submitted. Our team will review it.' });
  });

  // ── Disconnect ─────────────────────────────────────────────────────────────
  socket.on('disconnect', () => {
    console.log(`[-] Disconnected: ${socket.id}`);
    const queueIdx = waitingQueue.indexOf(socket);
    if (queueIdx !== -1) waitingQueue.splice(queueIdx, 1);
    handleLeave(socket, 'disconnected');
    io.emit('online_count', waitingQueue.length + Object.keys(activeRooms).length * 2);
  });
});

function handleLeave(socket, reason) {
  const roomId = socketToRoom[socket.id];
  if (!roomId || !activeRooms[roomId]) return;

  const room = activeRooms[roomId];
  const partner = room.user1.id === socket.id ? room.user2 : room.user1;
  const duration = Math.floor((Date.now() - room.startTime) / 1000);

  // Update session in DB
  db.prepare(`UPDATE chat_sessions SET ended_at = CURRENT_TIMESTAMP, duration_seconds = ?, message_count = ?, ended_by = ? WHERE session_id = ?`)
    .run(duration, room.messageCount, reason, room.sessionId);

  // Notify partner
  partner.emit('partner_left', { sessionId: room.sessionId, partnerSocketId: socket.id });

  // Cleanup
  delete activeRooms[roomId];
  delete socketToRoom[socket.id];
  delete socketToRoom[partner.id];
  socket.leave(roomId);
  partner.leave(roomId);
}

// ─── Frontend Routes ──────────────────────────────────────────────────────────
app.get('/', (req, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));
app.get('/chat', (req, res) => res.sendFile(path.join(__dirname, '../frontend/chat.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, '../frontend/login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, '../frontend/register.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, '../frontend/admin.html')));

// ─── Start Server ─────────────────────────────────────────────────────────────
server.listen(PORT, () => {
  console.log(`\n🔮 SPECTER Chat Server running at http://localhost:${PORT}`);
  console.log(`   Admin credentials: ${process.env.ADMIN_USERNAME || 'specter_admin'} / ${process.env.ADMIN_PASSWORD || 'specter_admin_2024'}\n`);
});
